import math
import random
import array
import wave


def save_wav(filename, buffer, sample_rate=44100):
    with wave.open(filename, 'wb') as f:
        f.setnchannels(1)
        f.setsampwidth(2)
        f.setframerate(sample_rate)
        f.writeframes(buffer.tobytes())


def generate_sounds():
    sample_rate = 44100
    sounds = ['laser', 'jump', 'die_leech', 'die_bomber', 'die_thief', 'mine_dirt', 'mine_stone', 'mine_gem', 'gold',
              'powerup']

    for sound_type in sounds:
        buffer = array.array('h')

        if sound_type == 'laser':
            duration = 0.5
            n_samples = int(sample_rate * duration)
            for i in range(n_samples):
                t = float(i) / sample_rate
                hum = math.sin(2 * math.pi * 180 * t)
                amp = (math.sin(2 * math.pi * 30 * t) + 1) / 2
                val = max(-1.0, min(1.0, hum * (0.5 + 0.5 * amp) + (0.8 if random.random() < 0.01 else 0)))
                buffer.append(int(val * 32767 * 0.2))

        elif sound_type == 'jump':
            duration = 0.2
            n_samples = int(sample_rate * duration)
            for i in range(n_samples):
                t = float(i) / sample_rate
                progress = i / n_samples
                freq = 150 + (300 * progress)
                tone = 2 * (t * freq - math.floor(t * freq + 0.5))
                noise = random.uniform(-1, 1) * (1 - (progress * 5)) if progress < 0.2 else 0
                envelope = progress / 0.1 if progress < 0.1 else 1 - ((progress - 0.1) / 0.9)
                buffer.append(int(((tone * 0.7) + (noise * 0.5)) * 32767 * 0.25 * envelope))

        elif sound_type == 'die_leech':
            duration = 0.3
            n_samples = int(sample_rate * duration)
            for i in range(n_samples):
                t = float(i) / sample_rate
                p = i / n_samples
                val = math.sin(2 * math.pi * (800 - (700 * (p ** 0.5))) * t) * (
                            0.8 + 0.2 * math.sin(2 * math.pi * 50 * t))
                buffer.append(int(val * 32767 * (0.4 * (1 - p))))

        elif sound_type == 'die_bomber':
            duration = 0.5
            n_samples = int(sample_rate * duration)
            last_val = 0
            for i in range(n_samples):
                t = float(i) / sample_rate
                p = i / n_samples
                tone = 1.0 if math.sin(2 * math.pi * (120 - (80 * p)) * t) > 0 else -1.0
                mix = ((tone * 0.3) + (random.uniform(-1, 1) * 0.7) + last_val) / 2.0
                last_val = mix
                buffer.append(int(mix * 32767 * (0.5 * (1 - p ** 2))))

        elif sound_type == 'die_thief':
            duration = 0.25
            n_samples = int(sample_rate * duration)
            for i in range(n_samples):
                t = float(i) / sample_rate
                p = i / n_samples
                period = 1.0 / (400 + (math.sin(2 * math.pi * 40 * t) * 50))
                val = 4 * abs((t % period) / period - 0.5) - 1
                buffer.append(int(val * 32767 * (0.4 * (1 - p))))

        elif sound_type == 'mine_dirt':
            duration = 0.1
            n_samples = int(sample_rate * duration)
            last_val = 0
            for i in range(n_samples):
                val = (random.uniform(-1, 1) + last_val * 3) / 4.0
                last_val = val
                buffer.append(int(val * 32767 * 0.5))

        elif sound_type == 'mine_stone':
            duration = 0.1
            n_samples = int(sample_rate * duration)
            pitch_mod = 1.0 + random.uniform(-0.1, 0.1)
            for i in range(n_samples):
                val = (random.uniform(-1, 1) * 0.7) + (
                            math.sin(2 * math.pi * (2000 * pitch_mod) * (i / sample_rate)) * 0.3)
                buffer.append(int(val * 32767 * 0.4 * (1.0 - (i / n_samples))))

        elif sound_type == 'mine_gem':
            duration = 0.3
            n_samples = int(sample_rate * duration)
            ting_freq = random.choice([880, 1100, 1320])
            for i in range(n_samples):
                t = float(i) / sample_rate
                p = i / n_samples
                val = (math.sin(2 * math.pi * ting_freq * t) * (1 - p) * 0.6) + (
                            random.uniform(-1, 1) * max(0, (1 - p * 4)) * 0.4)
                buffer.append(int(val * 32767 * 0.4))

        elif sound_type == 'gold':
            duration = 0.5
            n_samples = int(sample_rate * duration)
            for i in range(n_samples):
                t = float(i) / sample_rate
                p = i / n_samples
                val = max(-1.0, min(1.0, (
                            ((math.sin(2 * math.pi * 440 * t) + math.sin(2 * math.pi * 660 * t)) * 0.5 * 0.6) + (
                                random.uniform(-1, 1) * max(0, 1 - p * 5) * 0.4)) * (1 - p)))
                buffer.append(int(val * 32767 * 0.2))

        elif sound_type == 'powerup':
            duration = 0.6
            n_samples = int(sample_rate * duration)
            for i in range(n_samples):
                t = float(i) / sample_rate
                p = i / n_samples
                buffer.append(int(math.sin(2 * math.pi * (440 + (p * 880)) * t) * 0.5 * 32767 * (1 - p)))

        save_wav(f"{sound_type}.wav", buffer)
        print(f"Saved {sound_type}.wav")

    # Generate Ambient Music
    print("Generating music.wav (This may take a moment)...")
    bpm, beat_len = 100, 60 / 100
    sequence = [130.81, 196.00, 261.63, 196.00, 155.56, 233.08, 196.00, 155.56, 207.65, 155.56, 261.63, 155.56, 196.00,
                146.83, 123.47, 196.00]
    full_buffer = array.array('h')
    for note in sequence:
        duration = beat_len
        n_samples = int(sample_rate * duration)
        for i in range(n_samples):
            t = float(i) / sample_rate
            envelope = t / 0.1 if t < 0.1 else (duration - t) / 0.5 if t > duration - 0.5 else 1.0
            full_buffer.append(int(math.sin(2 * math.pi * note * t) * 32767 * envelope))

    save_wav("music.wav", full_buffer)
    print("Saved music.wav. All done!")


if __name__ == "__main__":
    generate_sounds()