# 2D Mining Game: "Deep Dive - FR Logic & Loot Update" (Web Version)

import asyncio
import pygame
import sys
import random
import math
import array

# ==============================================================================
# ### CONFIGURATION ###
# ==============================================================================

# --- ENEMY CONFIG ---
MAX_ENEMIES = 10
ENEMY_BASE_SPEED = 80.0
ENEMY_SPAWN_INTERVAL = 5
ENEMY_SPAWN_VARIANCE = 2.5
BOMBER_MAX_LIFETIME = 45.0

# --- NEW: FR (FIND & REPLACE) LOGIC ---
FR_TRIGGER_TIME = 60.0

# --- FRUSTRATION LOGIC SETTINGS ---
TRAP_RADIUS = 64.0
SEEK_TRIGGER_TIME = 2.0
SUPER_JUMP_TRIGGER_TIME = 10.0
SUPER_JUMP_MULTIPLIER = 1.6

# --- NEW: ORE GENERATION PROBABILITIES ---
ORE_DIAMOND_BASE = 0.005
ORE_DIAMOND_DEPTH_BONUS = 0.04
ORE_GOLD_BASE = 0.03
ORE_GOLD_DEPTH_BONUS = 0.08

# --- NEW: LOOT & COMBAT PRIZES ---
LOOT_DROP_RANGE_TILES = 2
LOOT_LIFETIME = 6.0
LOOT_FLASH_START = 3.0
SUPER_LASER_DURATION = 5.0
SUPER_LASER_MULTIPLIER = 3.0

# ==============================================================================
# ### SETTINGS ###
# ==============================================================================

WORLD_WIDTH = 60
WORLD_HEIGHT = 150
TILE_SIZE = 32
VIEW_W_TILES = 24
VIEW_H_TILES = 18
FPS = 60

# --- AUDIO VOLUMES ---
VOL_MUSIC = 0.05

# --- PHYSICS ---
PLAYER_SPEED = 230.0
GRAVITY = 1700.0
JUMP_FORCE = 620.0

MAX_OXYGEN = 100.0
OXYGEN_DRAIN_RATE = 2.0
OXYGEN_REFILL_RATE = 60.0

# --- LASER SETTINGS ---
LASER_MAX_ENERGY = 100.0
LASER_DRAIN_RATE = 15
LASER_RECHARGE_RATE = 35.0
LASER_RECHARGE_DELAY = 0.5

MINE_REACH = 6
MINING_SPEED = 0.25
LASER_DPS = 100.0

SURFACE_Y_LEVEL = 10

# --- COLORS ---
COLOR_BG = (15, 10, 25)
COLOR_SKY = (100, 150, 250)
COLOR_CAVE = (40, 60, 100)
COLOR_PLAYER = (255, 100, 100)
COLOR_LASER = (255, 50, 50)
COLOR_SUPER_LASER = (255, 180, 0)
COLOR_ENERGY = (0, 255, 255)
COLOR_MYSTERY = (25, 20, 30)

COLOR_LEECH = (150, 50, 200)
COLOR_BOMBER = (255, 100, 0)
COLOR_THIEF = (50, 200, 50)

BLOCK_DATA = {
    1: {"color": (100, 80, 50), "val": 0},
    2: {"color": (95, 95, 95), "val": 1},
    3: {"color": (40, 40, 40), "val": 10},
    4: {"color": (255, 215, 0), "val": 50},
    5: {"color": (0, 255, 255), "val": 200},
    99: {"color": (20, 0, 20), "val": 0},
}

GAME_WIDTH = VIEW_W_TILES * TILE_SIZE
GAME_HEIGHT = VIEW_H_TILES * TILE_SIZE

BLOCK_EMPTY = 0
BLOCK_BEDROCK = 99
ENEMY_TYPE_LEECH = 0
ENEMY_TYPE_BOMBER = 1
ENEMY_TYPE_THIEF = 2

pygame.mixer.pre_init(44100, -16, 1, 512)
pygame.init()
pygame.font.init()

# -------------------------------------------------
# DISPLAY SETUP FOR WEB
# -------------------------------------------------
WEB_W, WEB_H = 1920, 1080
screen = pygame.display.set_mode((WEB_W, WEB_H))
canvas = pygame.Surface((GAME_WIDTH, GAME_HEIGHT))

scale_w = WEB_W / GAME_WIDTH
scale_h = WEB_H / GAME_HEIGHT
render_scale = min(scale_w, scale_h)
output_w = int(GAME_WIDTH * render_scale)
output_h = int(GAME_HEIGHT * render_scale)
render_offset_x = (WEB_W - output_w) // 2
render_offset_y = (WEB_H - output_h) // 2

pygame.display.set_caption("Laser Miner Game")
clock = pygame.time.Clock()
font = pygame.font.SysFont("Arial", 20, bold=True)
inst_font = pygame.font.SysFont("Arial", 32, bold=True)  # New larger font for instructions
game_over_font = pygame.font.SysFont("Arial", 48, bold=True)
pause_font = pygame.font.SysFont("Arial", 64, bold=True)

# -------------------------------------------------
# LOAD TITLE ASSETS
# -------------------------------------------------
try:
    title_bg = pygame.image.load("laserminer_title_screen.jpg").convert()
    title_bg = pygame.transform.scale(title_bg, (WEB_W, WEB_H))
except Exception as e:
    print("Warning: Could not load laserminer_title_screen.jpg")
    title_bg = pygame.Surface((WEB_W, WEB_H))
    title_bg.fill((20, 20, 20))

# Menu Elements
btn_w, btn_h = 240, 60
play_btn = pygame.Rect(WEB_W // 2 - btn_w // 2, WEB_H // 2 - 40, btn_w, btn_h)
inst_btn = pygame.Rect(WEB_W // 2 - btn_w // 2, WEB_H // 2 + 40, btn_w, btn_h)

instructions_text = [
    "Welcome! In Laser Miner, your goal is to drill deep into the procedurally",
    "generated world to collect valuable ores like Gold and Diamonds while",
    "fighting off hostile creatures. Keep a close eye on your oxygen gauge,",
    "because you must return to the surface or find drops to refill it, or it's game over!",
    "",
    "For the best experience:",
    "> Play on a desktop or laptop computer. The game will not run correctly on a tablet or phone.",
    "> Use a Mouse: We highly recommend using an external mouse rather than a laptop trackpad.",
    "  The mining laser requires precise aiming that is difficult to achieve otherwise.",
    "> Use WASD Controls: While arrow keys work, using WASD allows you to move and jump agilely",
    "  with your left hand while aiming and shooting freely with your right.",
    "",
    "(Click anywhere to return to Title Screen)"
]


# -------------------------------------------------
# AUDIO ENGINE
# -------------------------------------------------
# -------------------------------------------------
# AUDIO ENGINE
# -------------------------------------------------
# Sound init
try:
    sfx_laser = pygame.mixer.Sound('laser.wav')
    sfx_jump = pygame.mixer.Sound('jump.wav')
    sfx_die_leech = pygame.mixer.Sound('die_leech.wav')
    sfx_die_bomber = pygame.mixer.Sound('die_bomber.wav')
    sfx_die_thief = pygame.mixer.Sound('die_thief.wav')
    sfx_mine_dirt = pygame.mixer.Sound('mine_dirt.wav')
    sfx_mine_stone = pygame.mixer.Sound('mine_stone.wav')
    sfx_mine_gem = pygame.mixer.Sound('mine_gem.wav')
    sfx_mine_gold = pygame.mixer.Sound('gold.wav')
    sfx_powerup = pygame.mixer.Sound('powerup.wav')
    sfx_boom = sfx_die_bomber
    sfx_pain = sfx_die_thief
    sfx_fizzle = sfx_mine_dirt
    sfx_crunch = sfx_mine_stone

    music_track = pygame.mixer.Sound('music.wav')
    music_track.set_volume(VOL_MUSIC)
except Exception as e:
    print(f"Warning: Missing audio files. Did you run make_sounds.py? Error: {e}")

music_channel = pygame.mixer.Channel(0)
laser_channel = pygame.mixer.Channel(1)
# -------------------------------------------------
# STATE
# -------------------------------------------------
player_width = int(TILE_SIZE * 0.65)
player_height = int(TILE_SIZE * 1.8)

grid = [[BLOCK_EMPTY for _ in range(WORLD_HEIGHT)] for _ in range(WORLD_WIDTH)]
active_enemies = []
particles = []
active_drops = []

spawn_timer = 2.0
screen_shake_amount = 0.0
damage_flash_timer = 0.0
player_dead = False
death_timer = 0.0
player_visible = True
laser_energy = LASER_MAX_ENERGY
laser_cooldown = 0.0
time_since_combat = 0.0
super_laser_timer = 0.0


def generate_world():
    for x in range(WORLD_WIDTH):
        for y in range(WORLD_HEIGHT):
            if y < SURFACE_Y_LEVEL:
                grid[x][y] = BLOCK_EMPTY
                continue
            if y == WORLD_HEIGHT - 1:
                grid[x][y] = BLOCK_BEDROCK
                continue
            depth_pct = (y - SURFACE_Y_LEVEL) / (WORLD_HEIGHT - SURFACE_Y_LEVEL)
            rand_val = random.random()
            diamond_chance = ORE_DIAMOND_BASE + (depth_pct * ORE_DIAMOND_DEPTH_BONUS)
            gold_chance = ORE_GOLD_BASE + (depth_pct * ORE_GOLD_DEPTH_BONUS)

            if rand_val < diamond_chance:
                grid[x][y] = 5
            elif rand_val < diamond_chance + gold_chance:
                grid[x][y] = 4
            elif rand_val < 0.08 + (depth_pct * 0.05):
                grid[x][y] = 3
            elif rand_val < 0.30 + (depth_pct * 0.20):
                grid[x][y] = 2
            else:
                grid[x][y] = 1

    cx = WORLD_WIDTH // 2
    for x in range(cx - 2, cx + 3):
        for y in range(SURFACE_Y_LEVEL - 2, SURFACE_Y_LEVEL + 5):
            if 0 <= x < WORLD_WIDTH and 0 <= y < WORLD_HEIGHT:
                grid[x][y] = BLOCK_EMPTY


generate_world()

player_x = (WORLD_WIDTH // 2) * TILE_SIZE
player_y = (SURFACE_Y_LEVEL - 2) * TILE_SIZE
player_vx = 0.0
player_vy = 0.0
cam_x = 0.0
cam_y = 0.0

current_oxygen = MAX_OXYGEN
score = 0
game_over = False
paused = False

mine_timer = 0.0
last_mine_target = None
laser_end_point = None


# -------------------------------------------------
# HELPERS
# -------------------------------------------------
def in_bounds_tile(tx, ty):
    return 0 <= tx < WORLD_WIDTH and 0 <= ty < WORLD_HEIGHT


def tile_at_pixel(px, py):
    return int(px // TILE_SIZE), int(py // TILE_SIZE)


def get_collision_rects(rect):
    hit_rects = []
    left = int(rect.left // TILE_SIZE)
    right = int((rect.right - 1) // TILE_SIZE)
    top = int(rect.top // TILE_SIZE)
    bottom = int((rect.bottom - 1) // TILE_SIZE)
    for tx in range(left, right + 1):
        for ty in range(top, bottom + 1):
            if in_bounds_tile(tx, ty):
                block = grid[tx][ty]
                if block != BLOCK_EMPTY:
                    hit_rects.append(pygame.Rect(tx * TILE_SIZE, ty * TILE_SIZE, TILE_SIZE, TILE_SIZE))
    return hit_rects


def move_entity_x(rect, vx, dt):
    rect.x += vx * dt
    collisions = get_collision_rects(rect)
    for tile_rect in collisions:
        if vx > 0:
            rect.right = tile_rect.left
        elif vx < 0:
            rect.left = tile_rect.right
    return rect


def move_entity_y(rect, vy, dt):
    rect.y += vy * dt
    collisions = get_collision_rects(rect)
    grounded = False
    for tile_rect in collisions:
        if vy > 0:
            rect.bottom = tile_rect.top
            grounded = True
            vy = 0
        elif vy < 0:
            rect.top = tile_rect.bottom
            vy = 0
    return rect, vy, grounded


def is_exposed_block(tx, ty):
    if not in_bounds_tile(tx, ty): return False
    for dx, dy in [(-1, 0), (1, 0), (0, -1), (0, 1)]:
        nx, ny = tx + dx, ty + dy
        if in_bounds_tile(nx, ny):
            if grid[nx][ny] == BLOCK_EMPTY: return True
        elif ny < 0:
            return True
    return False


def trigger_damage_feedback(amt=5.0):
    global screen_shake_amount, damage_flash_timer, time_since_combat
    time_since_combat = 0.0
    if not player_dead:
        sfx_pain.play()
        screen_shake_amount = min(20.0, screen_shake_amount + amt)
        damage_flash_timer = 0.2


# -------------------------------------------------
# PARTICLES & EXPLOSIONS
# -------------------------------------------------
def spawn_particles(x, y, count, color, speed_scale=1.0):
    for _ in range(count):
        angle = random.uniform(0, math.pi * 2)
        speed = random.uniform(50, 150) * speed_scale
        particles.append({
            'x': x, 'y': y,
            'vx': math.cos(angle) * speed, 'vy': math.sin(angle) * speed,
            'life': random.uniform(0.5, 1.2), 'color': color, 'size': random.randint(2, 5)
        })


def update_particles(dt):
    keep = []
    for p in particles:
        p['x'] += p['vx'] * dt;
        p['y'] += p['vy'] * dt
        p['life'] -= dt;
        p['vy'] += 300 * dt
        if p['life'] > 0: keep.append(p)
    return keep


def draw_particles(cam_x, cam_y):
    for p in particles:
        rect = pygame.Rect(p['x'] - cam_x, p['y'] - cam_y, p['size'], p['size'])
        pygame.draw.rect(canvas, p['color'], rect)


def explode(ex, ey, is_player=False):
    sfx_boom.play()
    global screen_shake_amount
    screen_shake_amount += 25.0 if is_player else 15.0
    ctx, cty = tile_at_pixel(ex, ey)
    radius = 4 if is_player else 3
    for x in range(ctx - radius, ctx + radius + 1):
        for y in range(cty - radius, cty + radius + 1):
            if in_bounds_tile(x, y) and grid[x][y] != BLOCK_BEDROCK:
                if grid[x][y] != BLOCK_EMPTY and random.random() < 0.3:
                    c = BLOCK_DATA[grid[x][y]]['color']
                    spawn_particles(x * TILE_SIZE, y * TILE_SIZE, 2, c)
                grid[x][y] = BLOCK_EMPTY
    color = COLOR_PLAYER if is_player else COLOR_BOMBER
    spawn_particles(ex, ey, 30 if is_player else 15, color, speed_scale=2.0 if is_player else 1.0)


# -------------------------------------------------
# DROPS LOGIC
# -------------------------------------------------
def spawn_drop(x, y, d_type, color):
    active_drops.append({'x': x, 'y': y, 'type': d_type, 'color': color, 'life': LOOT_LIFETIME})


def update_drops(dt):
    global score, current_oxygen, super_laser_timer
    keep = []
    pr = pygame.Rect(player_x, player_y, player_width, player_height)
    for d in active_drops:
        d['life'] -= dt
        drop_rect = pygame.Rect(d['x'] - 12, d['y'] - 12, 24, 24)
        if pr.colliderect(drop_rect):
            sfx_powerup.play()
            if d['type'] == ENEMY_TYPE_THIEF:
                score += 500
            elif d['type'] == ENEMY_TYPE_LEECH:
                current_oxygen = MAX_OXYGEN
            elif d['type'] == ENEMY_TYPE_BOMBER:
                super_laser_timer = SUPER_LASER_DURATION
            spawn_particles(d['x'], d['y'], 10, d['color'])
        elif d['life'] > 0:
            keep.append(d)
    return keep


def draw_drops(cam_x, cam_y):
    current_time = pygame.time.get_ticks()
    for d in active_drops:
        if d['life'] < LOOT_FLASH_START and (current_time // 150) % 2 == 0: continue
        sx, sy = int(d['x'] - cam_x), int(d['y'] - cam_y)
        glow_rad = 12 + math.sin(current_time * 0.01) * 2
        pygame.draw.circle(canvas, d['color'], (sx, sy), int(glow_rad), 2)
        pygame.draw.circle(canvas, (255, 255, 255), (sx, sy), 6)


# -------------------------------------------------
# ENEMY LOGIC
# -------------------------------------------------
def spawn_enemy():
    side = random.choice(['LEFT', 'RIGHT'])
    spawn_x = 10 if side == 'LEFT' else (WORLD_WIDTH * TILE_SIZE) - 50
    spawn_y = (SURFACE_Y_LEVEL - 3) * TILE_SIZE
    e_type = random.choice([ENEMY_TYPE_LEECH, ENEMY_TYPE_BOMBER, ENEMY_TYPE_THIEF])
    if e_type == ENEMY_TYPE_LEECH:
        w, h = 24, 16
    elif e_type == ENEMY_TYPE_BOMBER:
        w, h = 30, 30
    else:
        w, h = 16, 48

    active_enemies.append({
        'rect': pygame.Rect(spawn_x, spawn_y, w, h),
        'vx': 0.0, 'vy': 0.0, 'type': e_type,
        'hp': 40 if e_type == ENEMY_TYPE_BOMBER else 25,
        'grounded': False, 'flash_timer': 0.0, 'lifetime': 0.0,
        'mode': 'CHASE', 'trap_origin_x': spawn_x, 'trap_timer': 0.0,
        'seek_timer': 0.0, 'seek_dir': 0, 'super_jump_active': False
    })


def update_enemies(dt):
    global current_oxygen, score, time_since_combat
    p_rect = pygame.Rect(player_x, player_y, player_width, player_height)
    survivors = []
    pcx, pcy = player_x + player_width / 2, player_y + player_height / 2

    for e in active_enemies:
        e['lifetime'] += dt
        if e['type'] == ENEMY_TYPE_BOMBER and e['lifetime'] > BOMBER_MAX_LIFETIME:
            explode(e['rect'].centerx, e['rect'].centery)
            sfx_die_bomber.play()
            continue

        speed = ENEMY_BASE_SPEED * (
            1.5 if e['type'] == ENEMY_TYPE_LEECH else 0.6 if e['type'] == ENEMY_TYPE_BOMBER else 1.0)
        dist = abs(e['rect'].centerx - e['trap_origin_x'])
        if dist < TRAP_RADIUS + 32:
            e['trap_timer'] += dt
        else:
            e['trap_timer'] = 0.0
            e['trap_origin_x'] = e['rect'].centerx
            e['super_jump_active'] = False

        if e['trap_timer'] > SUPER_JUMP_TRIGGER_TIME and not e['super_jump_active']:
            e['super_jump_active'] = True
            spawn_particles(e['rect'].centerx, e['rect'].centery, 15, (255, 50, 50))

        player_is_below = p_rect.top > e['rect'].bottom + 10
        if not e['super_jump_active'] and e['mode'] != 'SEEK':
            if e['trap_timer'] > SEEK_TRIGGER_TIME and player_is_below:
                e['mode'] = 'SEEK'
                e['seek_timer'] = 8.0
                e['seek_dir'] = random.choice([-1, 1])
                e['vy'] = -200

        if not player_dead:
            if e['super_jump_active']:
                dx = p_rect.centerx - e['rect'].centerx
                e['vx'] = speed * 1.3 if dx > 0 else -speed * 1.3
                if abs(dx) < 10: e['vx'] = random.choice([-speed, speed])
            elif e['mode'] == 'SEEK':
                e['vx'] = e['seek_dir'] * (speed * 1.2)
                e['seek_timer'] -= dt
                if e['vy'] > 300 or e['seek_timer'] <= 0: e['mode'] = 'CHASE'
            else:
                dx = p_rect.centerx - e['rect'].centerx
                if abs(dx) < 8:
                    e['vx'] = 0
                elif dx > 0:
                    e['vx'] = speed
                else:
                    e['vx'] = -speed
        else:
            e['vx'] = 0

        check_dir = 1 if e['vx'] > 0 else -1
        look_x = e['rect'].right + 4 if check_dir > 0 else e['rect'].left - 4
        wall_ahead = len(get_collision_rects(pygame.Rect(look_x, e['rect'].top, 2, e['rect'].height - 2))) > 0

        if e['grounded']:
            do_jump = False
            final_jump = -550.0
            if e['super_jump_active']:
                do_jump, final_jump = True, -950.0
            else:
                if (e['mode'] == 'CHASE' and e['vx'] != 0 and wall_ahead) or (e['mode'] == 'SEEK' and wall_ahead):
                    do_jump = True
            if do_jump: e['vy'] = final_jump; e['grounded'] = False

        e['vy'] += GRAVITY * dt
        e['rect'] = move_entity_x(e['rect'], e['vx'], dt)
        e['rect'], e['vy'], e['grounded'] = move_entity_y(e['rect'], e['vy'], dt)

        kill = False
        if not player_dead and p_rect.colliderect(e['rect']):
            kill = True
            trigger_damage_feedback(10.0)
            if e['type'] == ENEMY_TYPE_LEECH:
                current_oxygen -= 15
            elif e['type'] == ENEMY_TYPE_THIEF:
                score = max(0, score - 200)
            elif e['type'] == ENEMY_TYPE_BOMBER:
                explode(e['rect'].centerx, e['rect'].centery)
                current_oxygen -= 20

        if e['hp'] <= 0: kill = True

        if kill:
            if e['type'] == ENEMY_TYPE_LEECH:
                sfx_die_leech.play()
            elif e['type'] == ENEMY_TYPE_BOMBER:
                sfx_die_bomber.play()
            elif e['type'] == ENEMY_TYPE_THIEF:
                sfx_die_thief.play()
            p_col = COLOR_LEECH if e['type'] == ENEMY_TYPE_LEECH else COLOR_BOMBER if e[
                                                                                          'type'] == ENEMY_TYPE_BOMBER else COLOR_THIEF
            spawn_particles(e['rect'].centerx, e['rect'].centery, 8, p_col)
            dist_sq = (pcx - e['rect'].centerx) ** 2 + (pcy - e['rect'].centery) ** 2
            if dist_sq < (LOOT_DROP_RANGE_TILES * TILE_SIZE) ** 2:
                spawn_drop(e['rect'].centerx, e['rect'].centery, e['type'], p_col)

        if e['flash_timer'] > 0: e['flash_timer'] -= dt
        if not kill: survivors.append(e)
    return survivors


def draw_enemies(cam_x, cam_y):
    for e in active_enemies:
        r = e['rect']
        scr = pygame.Rect(r.x - cam_x, r.y - cam_y, r.width, r.height)
        is_super = e['super_jump_active']
        base_color = COLOR_LEECH if e['type'] == ENEMY_TYPE_LEECH else COLOR_BOMBER if e[
                                                                                           'type'] == ENEMY_TYPE_BOMBER else COLOR_THIEF
        if is_super and (int(pygame.time.get_ticks() / 100) % 2 == 0):
            rv, gv, bv = base_color
            base_color = (min(255, rv + 60), min(255, gv + 60), min(255, bv + 60))
        c = (255, 255, 255) if e['flash_timer'] > 0 else base_color
        pygame.draw.rect(canvas, c, scr)
        detail_c = (255, 255, 0) if e['mode'] == 'SEEK' else (255, 0, 0) if is_super else (0, 0, 0)
        if e['type'] == ENEMY_TYPE_LEECH:
            pygame.draw.rect(canvas, detail_c, (scr.x + 4, scr.y + 4, 4, 4))
            pygame.draw.rect(canvas, detail_c, (scr.right - 8, scr.y + 4, 4, 4))
        elif e['type'] == ENEMY_TYPE_BOMBER:
            pygame.draw.rect(canvas, detail_c, (scr.centerx - 5, scr.centery - 5, 10, 10))
        elif e['type'] == ENEMY_TYPE_THIEF:
            pygame.draw.rect(canvas, detail_c, (scr.x, scr.y + 8, scr.w, 10))


# -------------------------------------------------
# UI & STATE LOGIC
# -------------------------------------------------
def update_camera(target_x, target_y):
    global cam_x, cam_y
    dz_w, dz_h = int(GAME_WIDTH * 0.2), int(GAME_HEIGHT * 0.3)
    dz = pygame.Rect(cam_x + dz_w, cam_y + dz_h, GAME_WIDTH - 2 * dz_w, GAME_HEIGHT - 2 * dz_h)
    if target_x < dz.left: cam_x -= (dz.left - target_x)
    if target_x > dz.right: cam_x += (target_x - dz.right)
    if target_y < dz.top: cam_y -= (dz.top - target_y)
    if target_y > dz.bottom: cam_y += (target_y - dz.bottom)
    cam_x = max(0.0, min(cam_x, float(WORLD_WIDTH * TILE_SIZE - GAME_WIDTH)))
    cam_y = max(0.0, min(cam_y, float(WORLD_HEIGHT * TILE_SIZE - GAME_HEIGHT)))


def draw_ui():
    bar_w = 200
    pct = max(0.0, current_oxygen / MAX_OXYGEN)
    col = (0, 255, 0) if pct > 0.5 else (255, 165, 0) if pct > 0.2 else (255, 0, 0)
    pygame.draw.rect(canvas, (255, 255, 255), (20, 20, bar_w, 20), 2)
    pygame.draw.rect(canvas, col, (22, 22, int((bar_w - 4) * pct), 16))
    canvas.blit(font.render(f"OXYGEN", True, (255, 255, 255)), (230, 20))

    e_pct = max(0.0, laser_energy / LASER_MAX_ENERGY)
    ecol = COLOR_SUPER_LASER if super_laser_timer > 0 else (100, 100, 100) if laser_energy <= 0.01 else (
    255, 100, 100) if laser_energy < 20 else COLOR_ENERGY
    pygame.draw.rect(canvas, (255, 255, 255), (20, 50, bar_w, 15), 2)
    pygame.draw.rect(canvas, ecol, (22, 52, int((bar_w - 4) * e_pct), 11))
    canvas.blit(font.render("LASER (MAX)" if super_laser_timer > 0 else "LASER", True, ecol), (230, 48))

    canvas.blit(font.render(f"SCORE: ${int(score)}", True, (255, 215, 0)), (GAME_WIDTH - 180, 20))
    canvas.blit(font.render(f"DEPTH: {int(player_y // TILE_SIZE)}m", True, (200, 200, 200)), (GAME_WIDTH - 180, 45))
    canvas.blit(font.render(f"ENEMIES: {len(active_enemies)}", True, (150, 150, 150)), (20, GAME_HEIGHT - 30))

    if paused:
        overlay = pygame.Surface((GAME_WIDTH, GAME_HEIGHT))
        overlay.set_alpha(100);
        overlay.fill((0, 0, 0))
        canvas.blit(overlay, (0, 0))
        t = pause_font.render("PAUSED", True, (255, 255, 255))
        canvas.blit(t, t.get_rect(center=(GAME_WIDTH // 2, GAME_HEIGHT // 2)))

    if game_over:
        overlay = pygame.Surface((GAME_WIDTH, GAME_HEIGHT))
        overlay.set_alpha(200);
        overlay.fill((0, 0, 0))
        canvas.blit(overlay, (0, 0))
        t = game_over_font.render("GAME OVER", True, (255, 50, 50))
        canvas.blit(t, t.get_rect(center=(GAME_WIDTH // 2, GAME_HEIGHT // 2 - 40)))
        s_text = game_over_font.render(f"FINAL SCORE: ${int(score)}", True, (255, 215, 0))
        canvas.blit(s_text, s_text.get_rect(center=(GAME_WIDTH // 2, GAME_HEIGHT // 2 + 20)))
        sub = font.render("Press R to return to Title Screen", True, (255, 255, 255))
        canvas.blit(sub, sub.get_rect(center=(GAME_WIDTH // 2, GAME_HEIGHT // 2 + 80)))

    if damage_flash_timer > 0:
        f = pygame.Surface((GAME_WIDTH, GAME_HEIGHT))
        f.fill((255, 0, 0))
        f.set_alpha(int(100 * (damage_flash_timer / 0.2)))
        canvas.blit(f, (0, 0))


def reset_game():
    global grid, player_x, player_y, player_vx, player_vy, score, current_oxygen, game_over
    global active_enemies, particles, player_dead, player_visible, laser_energy
    global active_drops, time_since_combat, super_laser_timer
    grid = [[BLOCK_EMPTY for _ in range(WORLD_HEIGHT)] for _ in range(WORLD_WIDTH)]
    generate_world()
    player_x = (WORLD_WIDTH // 2) * TILE_SIZE
    player_y = (SURFACE_Y_LEVEL - 2) * TILE_SIZE
    player_vx = 0;
    player_vy = 0;
    score = 0;
    current_oxygen = MAX_OXYGEN
    laser_energy = LASER_MAX_ENERGY;
    game_over = False;
    active_enemies = []
    particles = [];
    active_drops = [];
    player_dead = False;
    player_visible = True
    time_since_combat = 0.0;
    super_laser_timer = 0.0


# -------------------------------------------------
# ASYNC MAIN LOOP FOR PYGBAG
# -------------------------------------------------
async def main():
    global game_over, paused, jump_buffer, time_since_combat, super_laser_timer, spawn_timer
    global player_vx, player_vy, player_x, player_y, current_oxygen, player_dead, player_visible, death_timer
    global active_enemies, particles, active_drops, laser_energy, laser_cooldown, laser_end_point, target_block, last_mine_target, mine_timer
    global score, screen_shake_amount, damage_flash_timer

    running = True
    jump_buffer = 0
    game_state = "TITLE"  # "TITLE", "INSTRUCTIONS", "PLAYING"

    while running:
        dt = clock.tick(FPS) / 1000.0

        for event in pygame.event.get():
            if event.type == pygame.QUIT: running = False

            # --- STATE MACHINE EVENTS ---
            if game_state == "TITLE":
                if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                    if play_btn.collidepoint(event.pos):
                        reset_game()
                        game_state = "PLAYING"
                        # Web Audio Policy: Start audio on user gesture
                        if not music_channel.get_busy():
                            music_channel.play(music_track, -1)
                        else:
                            music_channel.unpause()
                    elif inst_btn.collidepoint(event.pos):
                        game_state = "INSTRUCTIONS"

            elif game_state == "INSTRUCTIONS":
                if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                    game_state = "TITLE"

            elif game_state == "PLAYING":
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_ESCAPE:
                        game_state = "TITLE"
                        if music_channel.get_busy():
                            music_channel.pause()
                    if event.key == pygame.K_p and not game_over and not player_dead:
                        paused = not paused
                        if paused:
                            laser_channel.stop();
                            music_channel.pause()
                        else:
                            music_channel.unpause()
                    if event.key == pygame.K_m:
                        if music_channel.get_busy():
                            music_channel.pause()
                        else:
                            music_channel.unpause()
                    if game_over and event.key == pygame.K_r:
                        game_state = "TITLE"  # Return to title per instructions
                        if music_channel.get_busy():
                            music_channel.pause()

        # --- STATE: TITLE ---
        if game_state == "TITLE":
            screen.blit(title_bg, (0, 0))

            # Draw Buttons
            pygame.draw.rect(screen, (150, 50, 50), play_btn)
            pygame.draw.rect(screen, (255, 255, 255), play_btn, 4)
            t_play = font.render("PLAY GAME", True, (255, 255, 255))
            screen.blit(t_play, t_play.get_rect(center=play_btn.center))

            pygame.draw.rect(screen, (50, 100, 150), inst_btn)
            pygame.draw.rect(screen, (255, 255, 255), inst_btn, 4)
            t_inst = font.render("INSTRUCTIONS", True, (255, 255, 255))
            screen.blit(t_inst, t_inst.get_rect(center=inst_btn.center))

            pygame.display.flip()

        # --- STATE: INSTRUCTIONS ---
        elif game_state == "INSTRUCTIONS":
            screen.blit(title_bg, (0, 0))
            overlay = pygame.Surface((WEB_W, WEB_H), pygame.SRCALPHA)
            overlay.fill((0, 0, 0, 200))  # Darker background for readability
            screen.blit(overlay, (0, 0))

            line_spacing = 50  # Increased spacing for the larger font
            start_y = WEB_H // 2 - (len(instructions_text) * line_spacing) // 2
            for i, line in enumerate(instructions_text):
                t_line = inst_font.render(line, True, (255, 255, 255))  # Using new inst_font
                screen.blit(t_line, t_line.get_rect(center=(WEB_W // 2, start_y + i * line_spacing)))

            pygame.display.flip()

        # --- STATE: PLAYING ---
        elif game_state == "PLAYING":
            if paused:
                draw_ui()
                screen.fill((0, 0, 0))
                scaled_surf = pygame.transform.scale(canvas, (output_w, output_h))
                screen.blit(scaled_surf, (render_offset_x, render_offset_y))
                pygame.display.flip()
                await asyncio.sleep(0)
                continue

            if not game_over:
                time_since_combat += dt
                if super_laser_timer > 0: super_laser_timer -= dt

                particles = update_particles(dt)
                active_enemies = update_enemies(dt)
                active_drops = update_drops(dt)

                spawn_timer -= dt
                if spawn_timer <= 0:
                    force_recycle = (time_since_combat > FR_TRIGGER_TIME and len(active_enemies) >= MAX_ENEMIES)
                    if force_recycle:
                        active_enemies.pop(0)
                        spawn_enemy()
                    elif len(active_enemies) < MAX_ENEMIES:
                        spawn_enemy()
                    spawn_timer = max(0.5, ENEMY_SPAWN_INTERVAL + random.uniform(-ENEMY_SPAWN_VARIANCE,
                                                                                 ENEMY_SPAWN_VARIANCE))

                if not player_dead:
                    keys = pygame.key.get_pressed()
                    dx = -1 if keys[pygame.K_LEFT] or keys[pygame.K_a] else 1 if keys[pygame.K_RIGHT] or keys[
                        pygame.K_d] else 0
                    if keys[pygame.K_SPACE] or keys[pygame.K_w]: jump_buffer = 5

                    player_vx = dx * PLAYER_SPEED
                    player_vy += GRAVITY * dt

                    pr = pygame.Rect(player_x, player_y, player_width, player_height)
                    pr = move_entity_x(pr, player_vx, dt)
                    player_x = pr.x
                    pr, player_vy, grounded = move_entity_y(pr, player_vy, dt)
                    player_y = pr.y

                    if jump_buffer > 0:
                        if grounded:
                            player_vy = -JUMP_FORCE;
                            sfx_jump.play();
                            jump_buffer = 0
                        else:
                            jump_buffer -= 1

                    mouse = pygame.mouse.get_pressed()
                    laser_end_point = None;
                    target_block = None

                    if mouse[0]:
                        if laser_energy > 0:
                            laser_cooldown = LASER_RECHARGE_DELAY
                            laser_energy -= LASER_DRAIN_RATE * dt
                            if not laser_channel.get_busy(): laser_channel.play(sfx_laser, loops=-1)

                            # Scaling correction for Web resolution
                            mx, my = pygame.mouse.get_pos()
                            mx = (mx - render_offset_x) / render_scale
                            my = (my - render_offset_y) / render_scale

                            pxc, pcy = player_x + player_width / 2, player_y + player_height / 2
                            wmx, wmy = mx + cam_x, my + cam_y
                            ang = math.atan2(wmy - pcy, wmx - pxc)

                            hit_pos = None;
                            max_d_sq = (MINE_REACH * TILE_SIZE) ** 2 + 1
                            for d in range(0, int(MINE_REACH * TILE_SIZE), 8):
                                cx, cy = pxc + math.cos(ang) * d, pcy + math.sin(ang) * d
                                tx, ty = tile_at_pixel(cx, cy)
                                if in_bounds_tile(tx, ty):
                                    blk = grid[tx][ty]
                                    if blk != BLOCK_EMPTY:
                                        max_d_sq = d * d
                                        if blk != BLOCK_BEDROCK and is_exposed_block(tx, ty):
                                            target_block = (tx, ty)
                                            hit_pos = (cx, cy)
                                        else:
                                            hit_pos = (cx, cy)
                                        break
                            if hit_pos:
                                laser_end_point = (hit_pos[0] - cam_x, hit_pos[1] - cam_y)
                            else:
                                laser_end_point = (pxc + math.cos(ang) * (MINE_REACH * TILE_SIZE) - cam_x,
                                                   pcy + math.sin(ang) * (MINE_REACH * TILE_SIZE) - cam_y)

                            l_end = (
                            pxc + math.cos(ang) * math.sqrt(max_d_sq), pcy + math.sin(ang) * math.sqrt(max_d_sq))

                            for e in active_enemies:
                                if e['rect'].clipline((pxc, pcy), l_end):
                                    time_since_combat = 0.0
                                    dmg = LASER_DPS * dt * (SUPER_LASER_MULTIPLIER if super_laser_timer > 0 else 1.0)
                                    e['hp'] -= dmg
                                    e['flash_timer'] = 0.1
                                    target_block = None
                        else:
                            if laser_channel.get_busy(): laser_channel.stop()
                            if random.random() < 0.05: sfx_fizzle.play()
                            target_block = None
                    else:
                        if laser_channel.get_busy(): laser_channel.fadeout(100)
                        if laser_cooldown > 0:
                            laser_cooldown -= dt
                        elif laser_energy < LASER_MAX_ENERGY:
                            laser_energy += LASER_RECHARGE_RATE * dt

                    laser_energy = max(0.0, min(laser_energy, LASER_MAX_ENERGY))

                    if target_block and laser_energy > 0:
                        if target_block == last_mine_target:
                            mine_timer += dt
                        else:
                            mine_timer = 0
                        last_mine_target = target_block

                        req_speed = MINING_SPEED * (0.5 if super_laser_timer > 0 else 1.0)
                        if mine_timer >= req_speed:
                            tx, ty = target_block
                            blk = grid[tx][ty]
                            if blk == 4:
                                sfx_mine_gold.play()
                            elif blk == 5:
                                sfx_mine_gem.play()
                            elif blk == 1:
                                sfx_mine_dirt.play()
                            else:
                                sfx_mine_stone.play()
                            score += BLOCK_DATA[blk]["val"]
                            grid[tx][ty] = BLOCK_EMPTY
                            mine_timer = 0;
                            last_mine_target = None
                            spawn_particles(tx * TILE_SIZE + 16, ty * TILE_SIZE + 16, 5, BLOCK_DATA[blk]['color'])
                    else:
                        mine_timer = 0;
                        last_mine_target = None

                    player_x = max(0, min(player_x, WORLD_WIDTH * TILE_SIZE - player_width))
                    player_y = max(0, min(player_y, WORLD_HEIGHT * TILE_SIZE - player_height))
                    if player_y < SURFACE_Y_LEVEL * TILE_SIZE:
                        current_oxygen += OXYGEN_REFILL_RATE * dt
                    else:
                        current_oxygen -= OXYGEN_DRAIN_RATE * dt
                    current_oxygen = max(0.0, min(current_oxygen, MAX_OXYGEN))

                    if current_oxygen <= 0:
                        player_dead = True;
                        player_visible = False
                        laser_channel.stop()
                        explode(player_x + player_width // 2, player_y + player_height // 2, is_player=True)
                        death_timer = 2.0
                else:
                    if laser_channel.get_busy(): laser_channel.stop()
                    death_timer -= dt
                    if death_timer <= 0: game_over = True

            if damage_flash_timer > 0: damage_flash_timer -= dt
            if screen_shake_amount > 0:
                screen_shake_amount -= 60 * dt
                if screen_shake_amount < 0: screen_shake_amount = 0

            update_camera(player_x + player_width // 2, player_y + player_height // 2)
            sx = random.uniform(-screen_shake_amount, screen_shake_amount)
            sy = random.uniform(-screen_shake_amount, screen_shake_amount)
            rcx, rcy = cam_x + sx, cam_y + sy

            canvas.fill(COLOR_BG)
            stx, sty = int(rcx // TILE_SIZE), int(rcy // TILE_SIZE)
            w_tiles, h_tiles = GAME_WIDTH // TILE_SIZE + 2, GAME_HEIGHT // TILE_SIZE + 2

            for tx in range(stx, stx + w_tiles):
                for ty in range(sty, sty + h_tiles):
                    if not in_bounds_tile(tx, ty): continue
                    wx, wy = tx * TILE_SIZE - rcx, ty * TILE_SIZE - rcy
                    if ty < SURFACE_Y_LEVEL:
                        pygame.draw.rect(canvas, COLOR_SKY, (wx, wy, TILE_SIZE, TILE_SIZE))
                    elif grid[tx][ty] == BLOCK_EMPTY:
                        pygame.draw.rect(canvas, COLOR_CAVE, (wx, wy, TILE_SIZE, TILE_SIZE))
                    blk = grid[tx][ty]
                    if blk != BLOCK_EMPTY:
                        if is_exposed_block(tx, ty):
                            pygame.draw.rect(canvas, BLOCK_DATA[blk]["color"], (wx, wy, TILE_SIZE, TILE_SIZE))
                            pygame.draw.rect(canvas, (0, 0, 0), (wx, wy, TILE_SIZE, TILE_SIZE), 1)
                        else:
                            pygame.draw.rect(canvas, COLOR_MYSTERY, (wx, wy, TILE_SIZE, TILE_SIZE))

            draw_enemies(rcx, rcy)
            draw_drops(rcx, rcy)
            draw_particles(rcx, rcy)

            if player_visible:
                pr_scr = pygame.Rect(int(player_x - rcx), int(player_y - rcy), player_width, player_height)
                pygame.draw.rect(canvas, COLOR_PLAYER, pr_scr)
                ex = pr_scr.x + (12 if player_vx > 0 else 4)
                pygame.draw.rect(canvas, (255, 255, 255), (ex, pr_scr.y + 10, 6, 6))

                if laser_end_point and laser_energy > 0:
                    adj = (laser_end_point[0] - sx, laser_end_point[1] - sy)
                    l_col = COLOR_SUPER_LASER if super_laser_timer > 0 else COLOR_LASER
                    width = 5 if super_laser_timer > 0 else 2
                    pygame.draw.line(canvas, l_col, (pr_scr.centerx, pr_scr.centery), adj, width)
                    pygame.draw.circle(canvas, (255, 0, 0), adj, 4)
                    if mine_timer > 0 and target_block:
                        rad = 6 + (mine_timer / (MINING_SPEED * (0.5 if super_laser_timer > 0 else 1.0))) * 8
                        pygame.draw.circle(canvas, (255, 255, 255), adj, int(rad), 2)

            draw_ui()

            # --- FINAL SCALING TO WEB WINDOW ---
            screen.fill((0, 0, 0))
            scaled_surf = pygame.transform.scale(canvas, (output_w, output_h))
            screen.blit(scaled_surf, (render_offset_x, render_offset_y))
            pygame.display.flip()

        # REQUIRED FOR PYGBAG
        await asyncio.sleep(0)


# Run the async loop
if __name__ == "__main__":
    asyncio.run(main())